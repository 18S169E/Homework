#pragma once

#include <string>

extern std::string FILE_IN;
extern std::string FILE_OUT;
